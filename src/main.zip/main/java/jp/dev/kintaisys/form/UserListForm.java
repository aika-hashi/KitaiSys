package jp.dev.kintaisys.form;

import lombok.Data;

@Data
public class UserListForm {
    private String loginId;
    private String userName;
}