package jp.dev.kintaisys.form;

public interface ValidGroup2 {

}
