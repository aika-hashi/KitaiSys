package jp.dev.kintaisys.form;

import lombok.Data;

@Data
public class LoginForm {
	private String loginId;
    private String password;
}
