package jp.dev.kintaisys.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/task/detail")
public class TaskDetailRestController {

	
}
