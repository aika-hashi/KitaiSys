package jp.dev.kintaisys.hello;

import lombok.Data;

@Data
public class Employee {
    private String employeeId;
    private String employeeName;
    private int employeeAge;
}
