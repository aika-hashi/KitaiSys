'use strict';

/** 画面ロード時の処理. */
jQuery(function($){

  /** ログインボタンを押したときの処理. */
  $('#btn-login').click(function (event) {
    // ユーザー更新
    loginUser();
  });
  
  
  function loginUser(){
	
}
  
}